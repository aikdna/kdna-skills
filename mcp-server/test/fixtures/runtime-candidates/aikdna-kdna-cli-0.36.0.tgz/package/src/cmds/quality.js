const { error, EXIT } = require('./_common');

function cmdDiff(args) {
  const { cmdDiff } = require('../diff');
  const jsonMode = args.includes('--json');
  const positional = args.filter((a) => !a.startsWith('--'));
  const a = positional[0];
  const b = positional[1];
  if (!a) {
    error(
      'Usage:\n' +
        '  kdna diff <name>@<from-version> <name>@<to-version>   Compare two versions\n' +
        '  kdna diff <name> [--json]            Installed vs registry-current\n' +
        '\n' +
        'Surfaces judgment-level diff: added/removed/changed axioms,\n' +
        'ontology, misunderstandings, banned terms, and stances.',
      EXIT.INPUT_ERROR,
    );
  }
  (async () => {
    try {
      await cmdDiff(a, b, args);
    } catch (e) {
      if (jsonMode) {
        console.log(JSON.stringify({ error: e.message }));
        process.exit(EXIT.VALIDATION_FAILED);
      }
      console.error(`Error: ${e.message}`);
      process.exit(EXIT.VALIDATION_FAILED);
    }
  })();
}

function cmdSearch(args) {
  const { cmdSearch } = require('../search');
  const json = args.includes('--json');
  const query = args
    .slice(1)
    .filter((a) => a !== '--json')
    .join(' ')
    .trim();
  cmdSearch(query, json);
}

function cmdAvailable(args) {
  const { cmdAvailable } = require('../agent');
  cmdAvailable(args);
}

function cmdMatch(args) {
  const { cmdMatch } = require('../agent');
  const positional = [];
  const flags = [];
  for (let i = 1; i < args.length; i++) {
    if (args[i].startsWith('--')) flags.push(args[i]);
    else positional.push(args[i]);
  }
  cmdMatch(positional.join(' ').trim(), flags);
}

function cmdSelect(args) {
  const { cmdSelect } = require('../agent');
  cmdSelect(args);
}

function cmdPostvalidate(args) {
  const { cmdPostvalidate } = require('../agent');
  cmdPostvalidate(args);
}

function cmdRoute(args) {
  const { cmdRoute } = require('../agent');
  const positional = args.filter((a) => !a.startsWith('--'));
  const flags = args.filter((a) => a.startsWith('--'));
  if (!positional[1]) {
    const { error, EXIT } = require('./_common');
    error('Usage: kdna route "<task description>" [--json] [--discover]', EXIT.INPUT_ERROR);
  }
  cmdRoute(positional.slice(1).join(' ').trim(), flags);
}

module.exports = {
  cmdDiff,
  cmdSearch,
  cmdAvailable,
  cmdMatch,
  cmdSelect,
  cmdPostvalidate,
  cmdRoute,
};
